# ALTOINDO - Android Native Application

## Project Overview
ALTOINDO adalah aplikasi Android native (Java) ekosistem keuangan MLM yang dikembangkan oleh Altomedia Management. Mengelola transaksi finansial (transfer, top-up QRIS, penarikan dana) antar member dengan sistem bonus afiliasi.

## Technology Stack
- **Platform**: Android Native (minSdk 24, targetSdk 34)
- **Language**: Java
- **Backend/Database**: Firebase Authentication, Firestore, Storage
- **Build System**: Gradle AGP 8.2.0 + ViewBinding + Java 8 compile options
- **UI**: Android XML Layouts + RecyclerView + CardView
- **Libraries**: ZXing (QR scan), QRGen/JitPack (QR generate), Glide 4.16 (images), Firebase BOM 32.7.0
- **Repo Management**: JitPack added to settings.gradle

## Project Structure
```
app/src/main/java/com/altomedia/altoindoapp/
  activities/   - Semua Activity (22 class)
  adapters/     - RecyclerView adapters (TransactionAdapter, NotificationAdapter)
  models/       - Data models (User, Transaction, NotificationMessage, BonusConfig, AppSetting, WithdrawRequest, TopupRequest, Product)
  utils/        - Helper classes (IDGenerator, FirebaseHelper)
app/src/main/res/
  layout/       - 22+ XML layout files
  values/       - strings.xml (includes account_types array)
app/src/main/AndroidManifest.xml  - SplashActivity set as launcher
server.js       - Node.js overview server on port 5000
```

## Key Activities (COMPLETED)
### Member Flow
- `SplashActivity` - Splash screen launcher
- `LoginActivity` - Firebase Auth login + Member ID login + Admin routing
- `RegisterActivity` - New member registration
- `MainActivity` - Dashboard utama (8 nav buttons)
- `TransferActivity` - Transfer saldo (PIN verif, QR scan, auto-deduct)
- `TopUpActivity` - Top-up via QRIS dengan timer 3 menit + save ke galeri
- `WithdrawActivity` - Penarikan dana + auto-deduct saldo + auto-isi rekening
- `ProfileActivity` - Profil + QR Code member untuk di-scan
- `UserProfileActivity` - Edit profil (ViewBinding migrated)
- `TransactionHistoryActivity` - RecyclerView riwayat transaksi user
- `NotificationsActivity` - RecyclerView notifikasi publik
- `SettingsActivity` - Setelan kontak & URL
- `ProductsActivity` - Daftar produk MLM
- `ScannerActivity` - QR Code scanner

### Admin Flow
- `AdminDashboardActivity` - Panel admin (6 menu + logout)
- `AdminUserManagementActivity` - Kelola pengguna
- `AdminTransactionManagementActivity` - Kelola transaksi
- `AdminNotificationManagementActivity` - Kelola notifikasi publik
- `AdminProductManagementActivity` - Kelola produk
- `AdminSettingsActivity` - Kelola setelan aplikasi
- `BonusManagementActivity` - Konfigurasi bonus + distribusi massal afiliasi

## Firestore Collections
- `users` - profil member (full_name, member_id, email, phone, balance_wallet, account_name, account_number, account_owner, account_type, upline_id)
- `transactions` - riwayat transaksi (id, uid, type, amount, fromMemberId, toMemberId, status, createdAt, description)
- `topups` - permintaan top-up QRIS
- `withdraw_requests` - permintaan penarikan dana (BUKAN "withdrawals")
- `notifications` - notifikasi publik admin (field: createdAt String)
- `bonus_config` - konfigurasi persentase bonus MLM
- `app_settings` - setelan aplikasi (kontak, URL)
- `products` - produk MLM (active=true untuk ditampilkan)

## Admin Credentials
- Email: appsidhanie@gmail.com
- Password: Kdsmedia@123
- Member ID: 14061993

## Bug Fixes Applied (Final Audit)
1. `AdminTransactionManagementActivity` - koleksi `withdrawals` → `withdraw_requests` (2 tempat: loadWithdrawals + updateWithdrawStatus)
2. `AdminNotificationManagementActivity` - field `created_at` (Long) → `createdAt` (String formatted) + import SimpleDateFormat/Date/Locale
3. `activity_admin_notifications.xml` - namespace XML: `schemas.android.com` → `http://schemas.android.com`
4. `FirebaseHelper.java` - null-safety saat baca `balance_wallet` (getLong bisa return null)
5. `build.gradle` - tambahkan `compileOptions` Java 8 (dibutuhkan Firebase Firestore)

## Running in Replit
Aplikasi Android tidak bisa dijalankan langsung di Replit. Node.js server (`server.js`) menampilkan project overview di port 5000.

Untuk build APK: `./gradlew assembleDebug` (memerlukan Android SDK)

## Workflow
- **Start application**: `node server.js` — port 5000

## Deployment
- Target: autoscale
- Run: `node server.js`
